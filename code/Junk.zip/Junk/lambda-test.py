
import boto3
import json
import logging
import os
import requests
from base64 import b64decode
import json

# The microsoft teams url

HOOK_URL = "https://outlook.office.com/webhook/c7a75da7-49ac-4d42-8d8f-e584e44a5202@f9d64c98-c3ad-4860-af38-fdf2610f9101/IncomingWebhook/ddf11718f2ce4e80ae3f5b06049e7b71/d0bc62e8-10e9-4a13-8bdc-4f33ce7f3e12"


message ={
            "@context": "https://schema.org/extensions",
            "@type": "MessageCard",
            "summary": "{\"instance-id\": \"i-0c9185f440359de67\", \"state\": \"running\"}"
        }
print(message)

teams_message = {
  "@context": "https://schema.org/extensions",
  "@type": "MessageCard",
  "title": "privo test",
  "summary": "privo-test",
}
print(teams_message)

response = requests.post(HOOK_URL, json.dumps(message).encode('utf-8'))
if response.status_code != 200:
    raise ValueError(
        'Request to teams returned an error %s, the response is:\n%s'
        % (response.status_code, response.text)
    )