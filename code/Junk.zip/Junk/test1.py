import json
import logging
import os
import boto3

from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

HOOK_URL = os.environ['WebHookUrl']

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_instance_name(instance-id):
  ec2 = boto3.client('ec2')
  response = ec2.describe_tags(
      Filters=[
        {
          'Name': 'resource-id',
          'Values': [instance_id,]
        },
      ]
  )
  for tag in response["Tags"]:
    if tag['Key'] == 'Name':
      instance_name = tag['Value']
  return instance_name

def lambda_handler(event, context):
    logger.info("Event: " + str(event))
    message = json.loads(event['Records'][0]['Sns']['Message'])
    logger.info("Message: " + str(message))
    message_type = message['detail-type']
    instance_id = message['detail']['instance-id']
    print(instance_id)
    instance_name = get_instance_name(instance-id)
    logger.info("Instance name %s",instance_name)

    data = {
        "colour": "64a837",
        "title": "**AWS Notification**",
        "text": "**%s** has been triggered" % message_type
    }

    if message_type == 'EC2 Instance State-change Notification':
        instance = ', '.join(message['resources'])
        state = message['detail']['state']
        data = {
            "colour": "64a837",
            "title": "**%s**" % message_type,
            "text": "**%s** state has been changed to **%s**" % (instance, state)
        }

    payload = {
      "@context": "https://schema.org/extensions",
      "@type": "MessageCard",
      "themeColor": data["colour"],
      "title": data["title"],
      "text": data["text"]
    }

    req = Request(HOOK_URL, json.dumps(payload).encode('utf-8'))
    try:
        response = urlopen(req)
        response.read()
        logger.info("Message posted")
    except HTTPError as e:
        logger.error("Request failed: %d %s", e.code, e.reason)
    except URLError as e:
        logger.error("Server connection failed: %s", e.reason)
