#!/bin/bash
#
# Delete default VPCs.  Prompts for confirmation by default.
# Safeguards - Check of ENIs and > 1 security group in the VPC.
#
set -eo pipefail

function usage
{
    printf "\nusage: %s [-h] --noprompt\n\n \
            \t--profile \tAWS Profile to use. REQUIRED.\n \
            \t--noprompt \tDo not prompt for deletions.\n \
            \t--use-keys \tIgnores profile. Used for access key shell vars.\n \
            \n" "$0"
}

# Usage if no args
if [ "$#" -lt 1 ]; then usage; exit; fi

# Collect arguments
for ARG in "$@"; do
  shift
    case $ARG in
        --profile )   export AWS_PROFILE="$1"
                      ;;
        --noprompt )  NOPROMPT="true"
                      ;;
        --use-keys )  USE_KEYS="true"
                      ;;
        -h | --help ) usage
                      exit
                      ;;
    esac
done

# Require a profile if we're not using keys
if [ "$AWS_PROFILE" = "" ] && [ "$USE_KEYS" != "true" ]; then usage; exit; fi

for REGION in $(aws ec2 describe-regions | jq -r ".Regions[].RegionName"); do

    # Check that the default VPC exists.  It may have already been deleted.
    DEFAULT_VPC=$(aws --region $REGION ec2 describe-vpcs --filters Name=isDefault,Values=true | jq -r '.Vpcs[].VpcId')

    if [ "$DEFAULT_VPC" = "" ]; then
      printf "No default VPC in %s. Skipping.\n" "$REGION"
      continue
    else

      # If --noprompt, then skip prompt between VPC deletions.
      if [ "$NOPROMPT" = "true" ]; then
        REPLY="y"
      else
        read -p "Will delete default VPC $DEFAULT_VPC in $REGION.  Continue? (y/n): " -n 1 -r
        printf "\n"
      fi

      if [[ $REPLY =~ ^[Yy]$ ]]; then
        # If noprompt is true, we'll still want to know what we're operating on.
        if [ "$NOPROMPT" = "true" ]; then printf "Deleting default VPC %s in %s\n" "$DEFAULT_VPC" "$REGION"; fi

        # Confirm there are no active ENIs in this VPC.  If so, exit
        VPC_ENI_COUNT=$(aws --region $REGION ec2 describe-network-interfaces --filters Name=vpc-id,Values=$DEFAULT_VPC |  jq '.NetworkInterfaces[].AvailabilityZone' | wc -l)
        VPC_SECURITY_GROUP_COUNT=$(aws --region $REGION ec2 describe-security-groups --filters Name=vpc-id,Values=$DEFAULT_VPC | jq -r '.SecurityGroups[].GroupName' | wc -l)

        if [ "$VPC_ENI_COUNT" -gt 0 ]; then
          printf "%s network interfaces in use.  Investigate manually.  Skipping.\n" "$VPC_ENI_COUNT"
          continue
        elif [ "$VPC_SECURITY_GROUP_COUNT" -gt 1 ]; then
          printf "%s security groups in use.  Investigate manually.  Skipping.\n" "$VPC_SECURITY_GROUP_COUNT"
          continue
        fi

        DEFAULT_IGW=$(aws --region $REGION ec2 describe-internet-gateways --filters Name=attachment.vpc-id,Values=$DEFAULT_VPC | jq -r ".InternetGateways[].InternetGatewayId")
        printf "Detaching and deleting IGW %s ... " "$DEFAULT_IGW"
        aws --region $REGION ec2 detach-internet-gateway --internet-gateway-id $DEFAULT_IGW --vpc-id $DEFAULT_VPC
        aws --region $REGION ec2 delete-internet-gateway --internet-gateway-id $DEFAULT_IGW
        printf "Done.\n"

        # Delete subnets
        for SUBNET in $(aws --region $REGION ec2 describe-subnets --filters Name=vpc-id,Values=$DEFAULT_VPC | jq -r ".Subnets[].SubnetId"); do
          printf "Deleting %s %s ... " "$DEFAULT_VPC" "$SUBNET"
          aws --region $REGION ec2 delete-subnet --subnet-id=$SUBNET
          printf "Done.\n"
        done

        # Remove VPC
        printf "Deleting default VPC %s ... " "$DEFAULT_VPC"
        aws --region $REGION ec2 delete-vpc --vpc-id=$DEFAULT_VPC
        printf "Done.\n"
        printf "Removal of default VPC %s for %s complete.\n\n" "$DEFAULT_VPC" "$REGION"
      fi
    fi
done